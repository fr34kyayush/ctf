from getlocalip import get_local_ip, get_interface_ip
from getmac import get_mac_address
import os
import time
from dotenv import load_dotenv
load_dotenv()

ipc = format(get_local_ip())

eth_mac = get_mac_address(interface="eth0")
win_mac = get_mac_address(interface="Ethernet 3")
ip_mac = get_mac_address(ip="192.168.1.101")
ip6_mac = get_mac_address(ip6="::1")
host_mac = get_mac_address(hostname="localhost")
updated_mac = get_mac_address(ip="10.0.0.1", network_request=True)

    # Changing the port used for updating ARP table (UDP packet)
from getmac import getmac
getmac.PORT = 44444  # Default: 55555

a = getmac.get_mac_address(ip=ipc, network_request=True)
#print(a)

def entry2(macadd):
    if (macadd==os.getenv('macaddress')):
        print("You got the flag")
    else:
        t = 1
        while t<=50:
            print("You have been hacked wait for 3 seconds")
            t = t+1
        print(".....1......")
        time.sleep(1)
        print(".....2......")
        time.sleep(1)
        print(".....3......")
        time.sleep(1)
        os.system("shutdown -r now")

def entry():
    user_id = input("Enter user id: ")
    passd = input("Enter user password: ")

    if (user_id==os.getenv('user')):
        if (passd==os.getenv('password')):
            entry2(a)
        else:
            print("Wrong password")
    else:
        print("Wrong user id")

entry()


